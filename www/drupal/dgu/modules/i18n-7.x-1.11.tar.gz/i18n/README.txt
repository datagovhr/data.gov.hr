
README.txt
==========

********************************************************************
This is i18n package 7.x, and will work with Drupal 7.x
********************************************************************
WARNING: DO READ THE INSTALL FILE AND the ON-LINE HANDBOOK
********************************************************************

This is a collection of modules providing multilingual features.
These modules will build onto Drupal 7 core features enabling a full multilingual site

Up to date documentation will be kept on-line at http://drupal.org/node/133977

Additional Support
=================
For support, please create a support request for this module's project:
  http://drupal.org/project/i18n

Support questions by email to the module maintainer will be simply ignored. Use the issue tracker.

Now if you want professional (paid) support the module maintainer may be available occassionally.
Drop me a message to check availability and hourly rates, http://reyero.net/en/contact

====================================================================
Jose A. Reyero, drupal at reyero dot net, http://reyero.net
