window.CKEDITOR_BASEPATH = '/profiles/dgu/libraries/ckeditor/';;
