Drupal.locale = { 'pluralFormula': function ($n) { return Number((((($n%10)==1)&&(($n%100)!=11))?(0):((((($n%10)>=2)&&(($n%10)<=4))&&((($n%100)<10)||(($n%100)>=20)))?(1):2))); }, 'strings': {"":{"An AJAX HTTP error occurred.":"Nastala je AJAX HTTP gre\u0161ka.","HTTP Result Code: !status":"HTTP kod: !status","An AJAX HTTP request terminated abnormally.":"AJAX HTTP zahtjev je nenormalno zavr\u0161io.","Debugging information follows.":"Slijede debug informacije.","Path: !uri":"Putanja: !uri","StatusText: !statusText":"StatusTekst: !statusText","ResponseText: !responseText":"ResponseText: !responseText","ReadyState: !readyState":"ReadyState: !readyState","Configure":"Konfiguriraj","Please wait...":"Molimo pri\u010dekajte...","Quick edit":"Brzo ure\u0111ivanje","OK":"U redu","Sorry!":"Ispri\u010davamo se","Discard changes?":"Odbaciti promjene?","You have unsaved changes":"Imate nespremljene promjene","Save":"Spremi","Discard changes":"Odbaciti promjene","Saving":"Spremanje u toku","Close":"Zatvoriti","Re-order rows by numerical weight instead of dragging.":"Prerasporedi redove po broj\u010danoj te\u017eini umjesto povla\u010denja.","Show row weights":"Prika\u017ei te\u017einu redova","Hide row weights":"Sakrij te\u017einu redova","Drag to re-order":"Povucite kako bi prerasporedili","Changes made in this table will not be saved until the form is submitted.":"Promjene u ovoj tablici ne\u0107e biti spremljene dok se obrazac ne otpremi.","Hide":"Sakrij","Show":"Prika\u017ei","(active tab)":"(aktivni tab)","Also allow !name role to !permission?":"Tako\u0111er dopusti !permission !name ulozi?","This permission is inherited from the authenticated user role.":"Ovo dopu\u0161tenje je naslije\u0111eno iz korisni\u010dke uloge.","Select all rows in this table":"Ozna\u010dite sve redove u tablici","Deselect all rows in this table":"Poni\u0161ti izbor svih redova u ovoj tablici","The selected file %filename cannot be uploaded. Only files with the following extensions are allowed: %extensions.":"Odabrana datoteka %filename nije mogla biti otpremljena. Samo datoteke sa sljede\u0107im nastavcima su dopu\u0161tene: %extensions.","Autocomplete popup":"Isko\u010dnik samodovr\u0161etka","Searching for matches...":"Tra\u017eim...","none":"ni\u0161ta","Loading token browser...":"U\u010ditavanje token preglednika...","Available tokens":"Dostupni tokeni","Insert this token into your form":"Stavite token u svoj obrazac","First click a text field to insert your tokens into.":"Prvo kliknuti na polje teksta kako bi ubacili tokene u nj.","Edit":"Uredi","Requires a title":"Naziv je nu\u017ean","Not published":"Nije objavljeno","Don\u0027t display post information":"Ne prikazuj informacije o unosu","Next":"Sljede\u0107i","Disabled":"Onemogu\u0107eno","Enabled":"Omogu\u0107eno","Sunday":"Nedjelja","Monday":"Ponedjeljak","Tuesday":"Utorak","Wednesday":"Srijeda","Thursday":"\u010cetvrtak","Friday":"Petak","Saturday":"Subota","Add":"Dodaj","Done":"Gotovo","Prev":"Predhodni","Mon":"Pon","Tue":"Uto","Wed":"Sri","Thu":"\u010cet","Fri":"Pet","Sat":"Sub","Sun":"Ned","January":"Sije\u010danj","February":"Velja\u010da","March":"O\u017eujak","April":"Travanj","May":"Svibanj","June":"Lipanj","July":"Srpanj","August":"Kolovoz","September":"Rujan","October":"Listopad","November":"Studeni","December":"Prosinac","Your search yielded no results":"Nema rezultata za tra\u017eenu pretragu","Today":"Danas","Jan":"Sij","Feb":"Velj","Mar":"O\u017eu","Apr":"Tra","Jun":"Lip","Jul":"Srp","Aug":"Kol","Sep":"Ruj","Oct":"Lis","Nov":"Stu","Dec":"Pro","Su":"Ne","Mo":"Po","Tu":"Ut","We":"Sr","Th":"\u010ce","Fr":"Pe","Sa":"Su","mm\/dd\/yy":"mm\/dd\/gg","Not in book":"Nije unutar knjige","New book":"Nova knjiga","By @name on @date":"Od @name u @date","By @name":"Od @name","Not in menu":"Nije u izborniku","Alias: @alias":"Nadimak: @alias","No alias":"Nema nadimka","New revision":"Nova revizija","The changes to these blocks will not be saved until the \u003Cem\u003ESave blocks\u003C\/em\u003E button is clicked.":"Promjene na ovim blokovima ne\u0107e biti sa\u010duvane sve dok ne kliknete na dugme \u003Cem\u003ESpremi blokove\u003C\/em\u003E.","Show shortcuts":"Prika\u017ei pre\u010dace","No revision":"Nema revizije","@number comments per page":"@number komentara po stranici","Not restricted":"Nije ograni\u010deno","Not customizable":"Nije prilagodljivo","Restricted to certain pages":"Ograni\u010deno na odre\u0111ene stranice","The block cannot be placed in this region.":"Blok ne mo\u017ee biti postavljen u ovu regiju.","Hide summary":"Sakrij sa\u017eetak","Edit summary":"Uredi sa\u017eetak","Hide shortcuts":"Sakrij pre\u010dace","Select all":"Odaberi sve","Other":"Ostalo","\u00ab Prev":"\u003C\u003C Pro\u0161li","Next \u00bb":"Slje \u003E\u003E"}} };;
(function ($) {

Drupal.behaviors.dateYearRange = {};

Drupal.behaviors.dateYearRange.attach = function (context, settings) {
  var $textfield, $textfields, i;

  // Turn the years back and forward fieldsets into dropdowns.
  $textfields = $('input.select-list-with-custom-option', context).once('date-year-range');
  for (i = 0; i < $textfields.length; i++) {
    $textfield = $($textfields[i]);
    new Drupal.dateYearRange.SelectListWithCustomOption($textfield);
  }
};


Drupal.dateYearRange = {};

/**
 * Constructor for the SelectListWithCustomOption object.
 *
 * This object is responsible for turning the years back and forward textfields
 * into dropdowns with an 'other' option that lets the user enter a custom
 * value.
 */
Drupal.dateYearRange.SelectListWithCustomOption = function ($textfield) {
  this.$textfield = $textfield;
  this.$description = $textfield.next('div.description');
  this.defaultValue = $textfield.val();
  this.$dropdown = this.createDropdown();
  this.$dropdown.insertBefore($textfield);
};

/**
 * Get the value of the textfield as it existed on page load.
 *
 * @param {String} type
 *   The type of the variable to be returned. Defaults to string.
 * @return
 *   The original value of the textfield. Returned as an integer, if the type
 *   parameter was 'int'.
 */
Drupal.dateYearRange.SelectListWithCustomOption.prototype.getOriginal = function (type) {
  var original;
  if (type === 'int') {
    original = parseInt(this.defaultValue, 10);
    if (window.isNaN(original)) {
      original = 0;
    }
  }
  else {
    original = this.defaultValue;
  }
  return original;
};

/**
 * Get the correct first value for the dropdown.
 */
Drupal.dateYearRange.SelectListWithCustomOption.prototype.getStartValue = function () {
  var direction = this.getDirection();
  var start;
  switch (direction) {
    case 'back':
      // For the 'years back' dropdown, the first option should be -10, unless
      // the default value of the textfield is even smaller than that.
      start = Math.min(this.getOriginal('int'), -10);
      break;
    case 'forward':
      start = 0;
      break;
  }
  return start;
};

/**
 * Get the correct last value for the dropdown.
 */
Drupal.dateYearRange.SelectListWithCustomOption.prototype.getEndValue = function () {
  var direction = this.getDirection();
  var end;
  var originalString = this.getOriginal();
  switch (direction) {
    case 'back':
      end = 0;
      break;
    case 'forward':
      // If the original value of the textfield is an absolute year such as
      // 2020, don't try to include it in the dropdown.
      if (originalString.indexOf('+') === -1) {
        end = 10;
      }
      // If the original value is a relative value (+x), we want it to be
      // included in the possible dropdown values.
      else {
        end = Math.max(this.getOriginal('int'), 10);
      }
      break;
  }
  return end;
};

/**
 * Create a dropdown select list with the correct options for this textfield.
 */
Drupal.dateYearRange.SelectListWithCustomOption.prototype.createDropdown = function () {
  var $dropdown = $('<select>').addClass('form-select date-year-range-select');
  var $option, i, value;
  var start = this.getStartValue();
  var end = this.getEndValue();
  var direction = this.getDirection();
  for (i = start; i <= end; i++) {
    // Make sure we include the +/- sign in the option value.
    value = i;
    if (i > 0) {
      value = '+' + i;
    }
    // Zero values must have a + or - in front.
    if (i === 0) {
      if (direction === 'back') {
        value = '-' + i;
      }
      else {
        value = '+' + i;
      }
    }
    $option = $('<option>' + Drupal.formatPlural(value, '@count year from now', '@count years from now') + '</option>').val(value);
    $dropdown.append($option);
  }
  // Create an 'Other' option.
  $option = $('<option class="custom-option">' + Drupal.t('Other') + '</option>').val('');
  $dropdown.append($option);

  // When the user changes the selected option in the dropdown, perform
  // appropriate actions (such as showing or hiding the textfield).
  $dropdown.bind('change', $.proxy(this.handleDropdownChange, this));

  // Set the initial value of the dropdown.
  this._setInitialDropdownValue($dropdown);
  return $dropdown;
};

Drupal.dateYearRange.SelectListWithCustomOption.prototype._setInitialDropdownValue = function ($dropdown) {
  var textfieldValue = this.getOriginal();
  // Determine whether the original textfield value exists in the dropdown.
  var possible = $dropdown.find('option[value="' + textfieldValue + '"]');
  // If the original textfield value is one of the dropdown options, preselect
  // it and hide the 'other' textfield.
  if (possible.length) {
    $dropdown.val(textfieldValue);
    this.hideTextfield();
  }
  // If the original textfield value isn't one of the dropdown options, choose
  // the 'Other' option in the dropdown.
  else {
    $dropdown.val('');
  }
};

/**
 * Determine whether this is the "years back" or "years forward" textfield.
 */
Drupal.dateYearRange.SelectListWithCustomOption.prototype.getDirection = function () {
  if (this.direction) {
    return this.direction;
  }
  var direction;
  if (this.$textfield.hasClass('back')) {
    direction = 'back';
  }
  else if (this.$textfield.hasClass('forward')) {
    direction = 'forward';
  }
  this.direction = direction;
  return direction;
};

/**
 * Change handler for the dropdown, to modify the textfield as appropriate.
 */
Drupal.dateYearRange.SelectListWithCustomOption.prototype.handleDropdownChange = function () {
  // Since the dropdown changed, we need to make the content of the textfield
  // match the (new) selected option.
  this.syncTextfield();

  // Show the textfield if the 'Other' option was selected, and hide it if one
  // of the preset options was selected.
  if ($(':selected', this.$dropdown).hasClass('custom-option')) {
    this.revealTextfield();
  }
  else {
    this.hideTextfield();
  }
};

/**
 * Display the textfield and its description.
 */
Drupal.dateYearRange.SelectListWithCustomOption.prototype.revealTextfield = function () {
  this.$textfield.show();
  this.$description.show();
};

/**
 * Hide the textfield and its description.
 */
Drupal.dateYearRange.SelectListWithCustomOption.prototype.hideTextfield = function () {
  this.$textfield.hide();
  this.$description.hide();
};

/**
 * Copy the selected value of the dropdown to the textfield.
 *
 * FAPI doesn't know about the JS-only dropdown, so the textfield needs to
 * reflect the value of the dropdown.
 */
Drupal.dateYearRange.SelectListWithCustomOption.prototype.syncTextfield = function () {
  var value = this.$dropdown.val();
  this.$textfield.val(value);
};

})(jQuery);
;
